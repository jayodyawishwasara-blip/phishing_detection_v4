#!/bin/bash
# ============================================================================
# PHISHING DEFENSE DASHBOARD - Production Deployment Script
# ============================================================================
# This script deploys the entire stack on an Ubuntu VPS:
#   - Node.js backend (with SQLite, JWT auth, Twilio)
#   - React frontend (production build)
#   - Caddy reverse proxy
#   - Systemd service
#   - UFW firewall
#   - Data directories
#   - Default admin user
#
# USAGE:
#   chmod +x deploy.sh
#   sudo ./deploy.sh
#
# After deployment, access via: http://<YOUR_VPS_IP> or https://<YOUR_DOMAIN>
# Default login: admin / PhishGuard@2026
# ============================================================================

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[⚠]${NC} $1"; }
err()  { echo -e "${RED}[✗]${NC} $1"; }
info() { echo -e "${BLUE}[→]${NC} $1"; }

# ============================================================================
# PRE-FLIGHT CHECKS
# ============================================================================

if [ "$(id -u)" -ne 0 ]; then
  err "This script must be run as root (use sudo)"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="/opt/phishing-defense"

echo ""
echo "=================================================================="
echo "   PHISHING DEFENSE DASHBOARD - Production Deployment"
echo "=================================================================="
echo ""
echo "   Install directory : $INSTALL_DIR"
echo "   Source directory   : $SCRIPT_DIR"
echo ""

# Check required source files
REQUIRED_FILES=("server-production.js" "package-production.json" "App-production.js" ".env.example" "Caddyfile" "phishing-defense.service")
for f in "${REQUIRED_FILES[@]}"; do
  if [ ! -f "$SCRIPT_DIR/$f" ]; then
    err "Missing required file: $f"
    err "Ensure all deployment files are in: $SCRIPT_DIR"
    exit 1
  fi
done
log "All required source files found"

# ============================================================================
# STEP 1: SYSTEM DEPENDENCIES
# ============================================================================

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 1: Installing System Dependencies"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

info "Updating package lists..."
apt-get update -qq

info "Installing system packages..."
apt-get install -y -qq \
  curl \
  wget \
  git \
  build-essential \
  python3 \
  ca-certificates \
  fonts-liberation \
  libappindicator3-1 \
  libasound2 \
  libatk-bridge2.0-0 \
  libatk1.0-0 \
  libc6 \
  libcairo2 \
  libcups2 \
  libdbus-1-3 \
  libexpat1 \
  libfontconfig1 \
  libgbm1 \
  libgcc1 \
  libglib2.0-0 \
  libgtk-3-0 \
  libnspr4 \
  libnss3 \
  libpango-1.0-0 \
  libpangocairo-1.0-0 \
  libstdc++6 \
  libx11-6 \
  libx11-xcb1 \
  libxcb1 \
  libxcomposite1 \
  libxcursor1 \
  libxdamage1 \
  libxext6 \
  libxfixes3 \
  libxi6 \
  libxrandr2 \
  libxrender1 \
  libxss1 \
  libxtst6 \
  lsb-release \
  xdg-utils \
  2>/dev/null

log "System packages installed"

# ============================================================================
# STEP 2: NODE.JS
# ============================================================================

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 2: Node.js Setup"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if ! command -v node &>/dev/null || [[ "$(node -v | cut -d. -f1 | tr -d 'v')" -lt 18 ]]; then
  info "Installing Node.js 20 LTS..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash - >/dev/null 2>&1
  apt-get install -y -qq nodejs
fi
log "Node.js $(node -v) ready"
log "npm $(npm -v) ready"

# ============================================================================
# STEP 3: CADDY
# ============================================================================

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 3: Caddy Web Server"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if ! command -v caddy &>/dev/null; then
  info "Installing Caddy..."
  apt-get install -y -qq debian-keyring debian-archive-keyring apt-transport-https 2>/dev/null
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg 2>/dev/null
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null
  apt-get update -qq
  apt-get install -y -qq caddy
fi
log "Caddy $(caddy version 2>/dev/null || echo 'installed') ready"

# ============================================================================
# STEP 4: CREATE SERVICE USER
# ============================================================================

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 4: Service User & Directories"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if ! id -u phishguard &>/dev/null; then
  useradd -r -m -s /bin/bash phishguard
  log "Created service user: phishguard"
else
  log "Service user phishguard already exists"
fi

# Create directory structure
mkdir -p "$INSTALL_DIR"/{frontend,backend,data/{logs,screenshots,domains,baseline}}
log "Directory structure created"

# ============================================================================
# STEP 5: DEPLOY BACKEND
# ============================================================================

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 5: Deploy Backend"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

info "Copying backend files..."
cp "$SCRIPT_DIR/server-production.js" "$INSTALL_DIR/backend/server-production.js"
cp "$SCRIPT_DIR/package-production.json" "$INSTALL_DIR/backend/package.json"

# Create .env from template if not exists
if [ ! -f "$INSTALL_DIR/backend/.env" ]; then
  # Generate a proper JWT secret
  JWT_SECRET_GEN=$(openssl rand -hex 32)

  cp "$SCRIPT_DIR/.env.example" "$INSTALL_DIR/backend/.env"
  sed -i "s|JWT_SECRET=CHANGE_ME_TO_A_RANDOM_64_CHAR_STRING|JWT_SECRET=${JWT_SECRET_GEN}|" "$INSTALL_DIR/backend/.env"
  sed -i "s|DATA_FOLDER=/opt/phishing-defense/data|DATA_FOLDER=${INSTALL_DIR}/data|" "$INSTALL_DIR/backend/.env"
  sed -i "s|BUILD_PATH=/opt/phishing-defense/frontend/build|BUILD_PATH=${INSTALL_DIR}/frontend/build|" "$INSTALL_DIR/backend/.env"
  chmod 600 "$INSTALL_DIR/backend/.env"
  log ".env created with generated JWT secret"
  warn "EDIT ${INSTALL_DIR}/backend/.env to configure Twilio and change admin password!"
else
  log ".env already exists (preserved)"
fi

info "Installing backend dependencies (this may take a few minutes)..."
cd "$INSTALL_DIR/backend"
npm install --production 2>&1 | tail -1
log "Backend dependencies installed"

# ============================================================================
# STEP 6: DEPLOY FRONTEND
# ============================================================================

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 6: Deploy Frontend"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

info "Creating React app..."
TEMP_REACT="/tmp/phishing-react-build-$$"
mkdir -p "$TEMP_REACT"
cd "$TEMP_REACT"

# Initialize React project
npx --yes create-react-app frontend-build --use-npm 2>&1 | tail -3
cd frontend-build

info "Installing frontend dependencies..."
npm install lucide-react 2>&1 | tail -1

# Copy production App.js
cp "$SCRIPT_DIR/App-production.js" src/App.js

# Create minimal index.css
cat > src/index.css << 'CSSEOF'
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

* {
  box-sizing: border-box;
}
CSSEOF

info "Building production frontend (this takes 1-3 minutes)..."
CI=true npm run build 2>&1 | tail -3

# Copy build to install dir
rm -rf "$INSTALL_DIR/frontend/build"
cp -r build "$INSTALL_DIR/frontend/build"
log "Frontend built and deployed"

# Cleanup
rm -rf "$TEMP_REACT"

# ============================================================================
# STEP 7: CONFIGURE CADDY
# ============================================================================

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 7: Configure Caddy"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Backup existing Caddyfile
if [ -f /etc/caddy/Caddyfile ]; then
  cp /etc/caddy/Caddyfile /etc/caddy/Caddyfile.bak.$(date +%s)
  warn "Existing Caddyfile backed up"
fi

cp "$SCRIPT_DIR/Caddyfile" /etc/caddy/Caddyfile

# Create log directory
mkdir -p /var/log/caddy
chown caddy:caddy /var/log/caddy

log "Caddyfile deployed"

# ============================================================================
# STEP 8: SYSTEMD SERVICE
# ============================================================================

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 8: Systemd Service"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

cp "$SCRIPT_DIR/phishing-defense.service" /etc/systemd/system/phishing-defense.service
systemctl daemon-reload
systemctl enable phishing-defense
log "Systemd service configured and enabled"

# ============================================================================
# STEP 9: PERMISSIONS
# ============================================================================

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 9: Setting Permissions"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

chown -R phishguard:phishguard "$INSTALL_DIR"
chmod -R 755 "$INSTALL_DIR"
chmod 600 "$INSTALL_DIR/backend/.env"
chown phishguard:phishguard "$INSTALL_DIR/backend/.env"
log "Permissions set"

# ============================================================================
# STEP 10: FIREWALL
# ============================================================================

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 10: Firewall Configuration"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if command -v ufw &>/dev/null; then
  ufw allow 22/tcp comment "SSH" 2>/dev/null || true
  ufw allow 80/tcp comment "HTTP" 2>/dev/null || true
  ufw allow 443/tcp comment "HTTPS" 2>/dev/null || true

  # Deny direct access to backend port from outside
  ufw deny 5000/tcp comment "Block direct backend access" 2>/dev/null || true

  if ! ufw status | grep -q "Status: active"; then
    warn "UFW is not active. Enable it with: sudo ufw enable"
  else
    log "UFW rules configured"
  fi
else
  warn "UFW not found. Configure firewall manually."
fi

# ============================================================================
# STEP 11: START SERVICES
# ============================================================================

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Step 11: Starting Services"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

info "Starting backend service..."
systemctl restart phishing-defense
sleep 3

if systemctl is-active --quiet phishing-defense; then
  log "Backend service is running"
else
  err "Backend service failed to start!"
  journalctl -u phishing-defense --no-pager -n 20
fi

info "Restarting Caddy..."
systemctl restart caddy
sleep 2

if systemctl is-active --quiet caddy; then
  log "Caddy is running"
else
  err "Caddy failed to start!"
  journalctl -u caddy --no-pager -n 20
fi

# ============================================================================
# DONE
# ============================================================================

# Get server IP
SERVER_IP=$(hostname -I | awk '{print $1}')

echo ""
echo "=================================================================="
echo "   ✅ DEPLOYMENT COMPLETE"
echo "=================================================================="
echo ""
echo "   📁 Installation: $INSTALL_DIR"
echo "   ├── frontend/build/   → React production build"
echo "   ├── backend/          → Node.js server + SQLite"
echo "   │   ├── .env          → Configuration (EDIT THIS!)"
echo "   │   └── package.json  → Dependencies"
echo "   └── data/             → Persistent data"
echo "       ├── phishing-defense.db  → SQLite database"
echo "       ├── baseline/     → Legitimate site snapshots"
echo "       ├── screenshots/  → Captured evidence"
echo "       ├── domains/      → Per-domain history"
echo "       └── logs/         → Detection logs (CSV)"
echo ""
echo "   🌐 Access Points:"
echo "   • Dashboard:  http://${SERVER_IP}"
echo "   • Health:     http://${SERVER_IP}/api/health"
echo ""
echo "   🔐 Default Login:"
echo "   • Username:   admin"
echo "   • Password:   PhishGuard@2026"
echo "   ⚠️  CHANGE THE PASSWORD AFTER FIRST LOGIN!"
echo ""
echo "   🔧 Service Management:"
echo "   • sudo systemctl status phishing-defense"
echo "   • sudo systemctl restart phishing-defense"
echo "   • sudo journalctl -u phishing-defense -f"
echo ""
echo "   📝 Configuration:"
echo "   • Edit:  sudo nano $INSTALL_DIR/backend/.env"
echo "   • Then:  sudo systemctl restart phishing-defense"
echo ""
echo "   📱 WhatsApp Alerts:"
echo "   • Configure Twilio credentials in .env file"
echo "   • Alerts fire on critical/warning threat detection"
echo ""
echo "   🔒 For HTTPS with a domain:"
echo "   • Edit /etc/caddy/Caddyfile"
echo "   • Replace ':80 {' with 'yourdomain.com {'"
echo "   • sudo systemctl restart caddy"
echo ""
echo "=================================================================="
