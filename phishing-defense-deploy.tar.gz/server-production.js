// ============================================================================
// PHISHING DEFENSE DASHBOARD - PRODUCTION SERVER
// Persistence (SQLite), JWT Auth, Twilio WhatsApp Alerts
// All original detection logic preserved exactly as-is
// ============================================================================

const express = require('express');
const cors = require('cors');
const fs = require('fs').promises;
const fsSync = require('fs');
const path = require('path');
const puppeteer = require('puppeteer');
const { createObjectCsvWriter } = require('csv-writer');
const crypto = require('crypto');
const { JSDOM } = require('jsdom');
const Jimp = require('jimp');
const natural = require('natural');
const pixelmatch = require('pixelmatch');
const { PNG } = require('pngjs');
const Database = require('better-sqlite3');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const app = express();
const PORT = process.env.PORT || 5000;

// ============================================================================
// CONFIGURATION
// ============================================================================

const CONFIG = {
  dataFolder: process.env.DATA_FOLDER || path.join(process.cwd(), 'phishing-data'),
  logsFolder: process.env.DATA_FOLDER ? path.join(process.env.DATA_FOLDER, 'logs') : path.join(process.cwd(), 'phishing-data', 'logs'),
  screenshotsFolder: process.env.DATA_FOLDER ? path.join(process.env.DATA_FOLDER, 'screenshots') : path.join(process.cwd(), 'phishing-data', 'screenshots'),
  domainsFolder: process.env.DATA_FOLDER ? path.join(process.env.DATA_FOLDER, 'domains') : path.join(process.cwd(), 'phishing-data', 'domains'),
  baselineFolder: process.env.DATA_FOLDER ? path.join(process.env.DATA_FOLDER, 'baseline') : path.join(process.cwd(), 'phishing-data', 'baseline'),
  legitimateDomain: process.env.LEGITIMATE_DOMAIN || 'combankdigital.com',
  refreshInterval: parseInt(process.env.BASELINE_REFRESH_MS) || 3600000, // 1 hour
  whitelist: (process.env.WHITELIST_DOMAINS || 'combankdigital.com,combank.com,combank.lk').split(','),
  thresholds: {
    critical: parseInt(process.env.THRESHOLD_CRITICAL) || 85,
    warning: parseInt(process.env.THRESHOLD_WARNING) || 70,
    suspicious: parseInt(process.env.THRESHOLD_SUSPICIOUS) || 55
  }
};

const JWT_SECRET = process.env.JWT_SECRET || 'change-this-in-production-' + crypto.randomBytes(16).toString('hex');
const JWT_EXPIRY = process.env.JWT_EXPIRY || '24h';

// Twilio config
const TWILIO_ENABLED = !!(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN);
const TWILIO_CONFIG = {
  accountSid: process.env.TWILIO_ACCOUNT_SID || '',
  authToken: process.env.TWILIO_AUTH_TOKEN || '',
  fromNumber: process.env.TWILIO_WHATSAPP_FROM || 'whatsapp:+14155238886',
  toNumber: process.env.TWILIO_WHATSAPP_TO || '',
  maxRetries: parseInt(process.env.TWILIO_MAX_RETRIES) || 3
};

let twilioClient = null;
if (TWILIO_ENABLED) {
  try {
    const twilio = require('twilio');
    twilioClient = twilio(TWILIO_CONFIG.accountSid, TWILIO_CONFIG.authToken);
    console.log('✓ Twilio WhatsApp alerts enabled');
  } catch (e) {
    console.log('⚠ Twilio module not found, WhatsApp alerts disabled');
  }
}

// ============================================================================
// MIDDLEWARE
// ============================================================================

app.use(cors());
app.use(express.json());

// Serve React build (static files)
const buildPath = process.env.BUILD_PATH || path.join(process.cwd(), '..', 'build');
if (fsSync.existsSync(buildPath)) {
  app.use(express.static(buildPath));
  console.log(`✓ Serving static files from: ${buildPath}`);
}

// Serve screenshots
app.use('/api/screenshots-static', express.static(CONFIG.screenshotsFolder));

// ============================================================================
// DATABASE INITIALIZATION (SQLite)
// ============================================================================

let db;

function initDatabase() {
  const dbPath = path.join(CONFIG.dataFolder, 'phishing-defense.db');
  db = new Database(dbPath);

  // Enable WAL mode for better concurrent performance
  db.pragma('journal_mode = WAL');

  // Create tables
  db.exec(`
    CREATE TABLE IF NOT EXISTS domains (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      domain TEXT UNIQUE NOT NULL,
      status TEXT DEFAULT 'active',
      is_active INTEGER DEFAULT 0,
      similarity INTEGER DEFAULT 0,
      threat_level TEXT DEFAULT 'unknown',
      scores_json TEXT DEFAULT '{}',
      filters_json TEXT DEFAULT '[]',
      is_filtered INTEGER DEFAULT 0,
      screenshot_path TEXT,
      last_checked TEXT,
      added_at TEXT NOT NULL,
      monitoring_enabled INTEGER DEFAULT 1,
      scan_count INTEGER DEFAULT 0,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS alerts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      domain TEXT NOT NULL,
      similarity INTEGER DEFAULT 0,
      severity TEXT NOT NULL,
      threat_level TEXT,
      scores_json TEXT DEFAULT '{}',
      screenshot_path TEXT,
      detected_at TEXT NOT NULL,
      status TEXT DEFAULT 'pending',
      whatsapp_status TEXT DEFAULT 'not_sent',
      whatsapp_attempts INTEGER DEFAULT 0,
      whatsapp_last_error TEXT,
      whatsapp_sent_at TEXT,
      dismissed INTEGER DEFAULT 0,
      dismissed_at TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS scan_progress (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      scan_id TEXT UNIQUE NOT NULL,
      total_domains INTEGER DEFAULT 0,
      scanned_domains INTEGER DEFAULT 0,
      current_domain TEXT,
      current_phase TEXT,
      started_at TEXT NOT NULL,
      completed_at TEXT,
      status TEXT DEFAULT 'running'
    );

    CREATE TABLE IF NOT EXISTS whatsapp_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      alert_id INTEGER,
      message_sid TEXT,
      to_number TEXT,
      status TEXT NOT NULL,
      error_message TEXT,
      attempt_number INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (alert_id) REFERENCES alerts(id)
    );

    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT DEFAULT (datetime('now')),
      last_login TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_domains_domain ON domains(domain);
    CREATE INDEX IF NOT EXISTS idx_alerts_domain ON alerts(domain);
    CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);
    CREATE INDEX IF NOT EXISTS idx_whatsapp_log_alert ON whatsapp_log(alert_id);
  `);

  console.log(`✓ Database initialized: ${dbPath}`);
}

function ensureDefaultAdmin() {
  const adminUser = process.env.ADMIN_USERNAME || 'admin';
  const adminPass = process.env.ADMIN_PASSWORD || 'PhishGuard@2026';

  const existing = db.prepare('SELECT id FROM admin_users WHERE username = ?').get(adminUser);
  if (!existing) {
    const hash = bcrypt.hashSync(adminPass, 12);
    db.prepare('INSERT INTO admin_users (username, password_hash) VALUES (?, ?)').run(adminUser, hash);
    console.log(`✓ Default admin user created: ${adminUser}`);
  }
}

// ============================================================================
// JWT AUTHENTICATION MIDDLEWARE
// ============================================================================

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const user = jwt.verify(token, JWT_SECRET);
    req.user = user;
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Invalid or expired token' });
  }
}

// ============================================================================
// AUTH ROUTES (unprotected)
// ============================================================================

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password required' });
  }

  const user = db.prepare('SELECT * FROM admin_users WHERE username = ?').get(username);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  // Update last login
  db.prepare('UPDATE admin_users SET last_login = datetime("now") WHERE id = ?').run(user.id);

  const token = jwt.sign(
    { id: user.id, username: user.username },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRY }
  );

  res.json({ token, username: user.username, expiresIn: JWT_EXPIRY });
});

app.post('/api/auth/verify', (req, res) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ valid: false });
  }

  try {
    const user = jwt.verify(token, JWT_SECRET);
    res.json({ valid: true, username: user.username });
  } catch {
    res.status(401).json({ valid: false });
  }
});

app.post('/api/auth/change-password', authenticateToken, (req, res) => {
  const { currentPassword, newPassword } = req.body;

  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: 'Current and new password required' });
  }

  const user = db.prepare('SELECT * FROM admin_users WHERE id = ?').get(req.user.id);
  if (!bcrypt.compareSync(currentPassword, user.password_hash)) {
    return res.status(401).json({ error: 'Current password is incorrect' });
  }

  const newHash = bcrypt.hashSync(newPassword, 12);
  db.prepare('UPDATE admin_users SET password_hash = ? WHERE id = ?').run(newHash, req.user.id);
  res.json({ success: true });
});

// ============================================================================
// PROTECTED API ROUTES - Apply auth to all /api/* except auth routes
// ============================================================================

// Health check (unprotected for load balancer probes)
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    baseline: baselineManager.baseline ? 'loaded' : 'not loaded',
    lastUpdate: baselineManager.lastUpdate,
    twilioEnabled: TWILIO_ENABLED,
    dbConnected: !!db
  });
});

// All other API routes are protected
app.use('/api', (req, res, next) => {
  // Skip auth routes and health check
  if (req.path.startsWith('/auth/') || req.path === '/health') {
    return next();
  }
  authenticateToken(req, res, next);
});

// ============================================================================
// INITIALIZE DIRECTORIES
// ============================================================================

async function initializeDirectories() {
  const dirs = [
    CONFIG.dataFolder,
    CONFIG.logsFolder,
    CONFIG.screenshotsFolder,
    CONFIG.domainsFolder,
    CONFIG.baselineFolder
  ];

  for (const dir of dirs) {
    try {
      await fs.access(dir);
    } catch {
      await fs.mkdir(dir, { recursive: true });
      console.log(`✓ Created directory: ${dir}`);
    }
  }
}

// ============================================================================
// BASELINE MANAGEMENT (ORIGINAL - UNCHANGED)
// ============================================================================

class BaselineManager {
  constructor() {
    this.baseline = null;
    this.lastUpdate = null;
  }

  async crawlLegitimateWebsite(domain) {
    console.log(`\n📡 Crawling baseline website: ${domain}`);

    let browser;
    try {
      browser = await puppeteer.launch({
        headless: 'new',
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
      });

      const page = await browser.newPage();
      await page.setViewport({ width: 1920, height: 1080 });

      await page.goto(`https://${domain}`, {
        waitUntil: 'networkidle2',
        timeout: 30000
      });

      await page.waitForTimeout(2000);

      const data = await page.evaluate(() => {
        const removeTimestamps = (text) => {
          return text
            .replace(/\d{4}-\d{2}-\d{2}/g, 'DATE')
            .replace(/\d{2}:\d{2}:\d{2}/g, 'TIME')
            .replace(/\d{13,}/g, 'TIMESTAMP')
            .replace(/[a-f0-9]{32,}/gi, 'HASH');
        };

        const bodyText = document.body.innerText || '';
        const normalizedText = removeTimestamps(bodyText);

        const keywords = [];
        const keywordElements = document.querySelectorAll('h1, h2, h3, .logo, .brand, #logo, [class*="logo"], [class*="brand"]');
        keywordElements.forEach(el => {
          if (el.textContent.trim()) {
            keywords.push(el.textContent.trim().toLowerCase());
          }
        });

        const forms = [];
        document.querySelectorAll('form').forEach(form => {
          const fields = [];
          form.querySelectorAll('input, select, textarea').forEach(input => {
            fields.push({
              type: input.type || input.tagName.toLowerCase(),
              name: input.name,
              id: input.id,
              placeholder: input.placeholder
            });
          });
          forms.push({ fields, action: form.action });
        });

        const getDOMStructure = (node, depth = 0) => {
          if (depth > 5) return null;
          const structure = {
            tag: node.tagName,
            classes: Array.from(node.classList || []),
            id: node.id
          };
          if (node.children.length > 0 && depth < 5) {
            structure.children = Array.from(node.children)
              .slice(0, 10)
              .map(child => getDOMStructure(child, depth + 1))
              .filter(Boolean);
          }
          return structure;
        };

        const domStructure = getDOMStructure(document.body);

        const meta = {
          title: document.title,
          description: document.querySelector('meta[name="description"]')?.content || '',
          keywords: document.querySelector('meta[name="keywords"]')?.content || ''
        };

        const links = Array.from(document.querySelectorAll('a')).map(a => a.href);

        return {
          text: normalizedText,
          keywords: [...new Set(keywords)],
          forms,
          domStructure,
          meta,
          links: links.slice(0, 50)
        };
      });

      const screenshotPath = path.join(CONFIG.baselineFolder, `baseline_${Date.now()}.png`);
      await page.screenshot({
        path: screenshotPath,
        fullPage: false
      });

      const html = await page.content();

      const baseline = {
        domain,
        timestamp: new Date().toISOString(),
        data,
        html,
        screenshotPath,
        textHash: this.hashContent(data.text),
        domHash: this.hashContent(JSON.stringify(data.domStructure))
      };

      await fs.writeFile(
        path.join(CONFIG.baselineFolder, 'baseline.json'),
        JSON.stringify(baseline, null, 2)
      );

      console.log(`✓ Baseline captured: ${Object.keys(data).length} features extracted`);
      return baseline;

    } catch (error) {
      console.error(`✗ Baseline capture failed:`, error.message);
      return null;
    } finally {
      if (browser) await browser.close();
    }
  }

  async loadBaseline() {
    try {
      const baselinePath = path.join(CONFIG.baselineFolder, 'baseline.json');
      const content = await fs.readFile(baselinePath, 'utf8');
      this.baseline = JSON.parse(content);
      this.lastUpdate = new Date(this.baseline.timestamp);
      console.log(`✓ Baseline loaded: ${this.lastUpdate.toLocaleString()}`);
      return this.baseline;
    } catch {
      console.log(`⚠ No baseline found, creating new...`);
      return await this.refreshBaseline();
    }
  }

  async refreshBaseline() {
    this.baseline = await this.crawlLegitimateWebsite(CONFIG.legitimateDomain);
    this.lastUpdate = new Date();
    return this.baseline;
  }

  async ensureFreshBaseline() {
    if (!this.baseline || !this.lastUpdate) {
      await this.loadBaseline();
    }

    const age = Date.now() - this.lastUpdate.getTime();
    if (age > CONFIG.refreshInterval) {
      console.log(`⟳ Baseline is ${Math.round(age / 60000)} minutes old, refreshing...`);
      await this.refreshBaseline();
    }

    return this.baseline;
  }

  hashContent(content) {
    return crypto.createHash('sha256').update(content).digest('hex');
  }
}

const baselineManager = new BaselineManager();

// ============================================================================
// PHISHING DETECTION ENGINE (ORIGINAL - UNCHANGED)
// ============================================================================

class PhishingDetector {
  constructor(baseline) {
    this.baseline = baseline;
    this.TfIdf = natural.TfIdf;
    this.tfidf = new this.TfIdf();
  }

  // 1. TEXT SIMILARITY (25% weight)
  calculateTextSimilarity(suspiciousText) {
    if (!this.baseline || !suspiciousText) return 0;

    const baselineText = this.baseline.data.text;

    this.tfidf.addDocument(baselineText);
    this.tfidf.addDocument(suspiciousText);

    const terms = new Set([
      ...baselineText.split(/\s+/),
      ...suspiciousText.split(/\s+/)
    ]);

    let dotProduct = 0;
    let baseMagnitude = 0;
    let suspMagnitude = 0;

    terms.forEach(term => {
      const baseTfidf = this.tfidf.tfidf(term, 0);
      const suspTfidf = this.tfidf.tfidf(term, 1);

      dotProduct += baseTfidf * suspTfidf;
      baseMagnitude += baseTfidf * baseTfidf;
      suspMagnitude += suspTfidf * suspTfidf;
    });

    const cosineSim = dotProduct / (Math.sqrt(baseMagnitude) * Math.sqrt(suspMagnitude));
    return Math.min(100, Math.max(0, cosineSim * 100));
  }

  // 2. BRAND KEYWORD MATCHING (15% weight)
  calculateKeywordSimilarity(suspiciousData) {
    if (!this.baseline || !suspiciousData) return 0;

    const baselineKeywords = this.baseline.data.keywords.map(k => k.toLowerCase());
    const suspiciousText = suspiciousData.text.toLowerCase();

    let matches = 0;
    let total = baselineKeywords.length;

    baselineKeywords.forEach(keyword => {
      if (suspiciousText.includes(keyword)) {
        matches++;
      }
    });

    return total > 0 ? (matches / total) * 100 : 0;
  }

  // 3. DOM STRUCTURE SIMILARITY (20% weight)
  calculateDOMSimilarity(suspiciousDom) {
    if (!this.baseline || !suspiciousDom) return 0;

    const baseDom = this.baseline.data.domStructure;

    const similarity = this.compareDOMTrees(baseDom, suspiciousDom);
    return similarity * 100;
  }

  compareDOMTrees(tree1, tree2, depth = 0) {
    if (!tree1 || !tree2) return 0;
    if (depth > 5) return 0.5;

    let score = 0;
    let comparisons = 0;

    if (tree1.tag === tree2.tag) {
      score += 1;
    }
    comparisons++;

    if (tree1.classes && tree2.classes) {
      const intersection = tree1.classes.filter(c => tree2.classes.includes(c));
      const union = [...new Set([...tree1.classes, ...tree2.classes])];
      score += union.length > 0 ? intersection.length / union.length : 0;
      comparisons++;
    }

    if (tree1.children && tree2.children) {
      const minLength = Math.min(tree1.children.length, tree2.children.length);
      for (let i = 0; i < minLength; i++) {
        score += this.compareDOMTrees(tree1.children[i], tree2.children[i], depth + 1);
        comparisons++;
      }
    }

    return comparisons > 0 ? score / comparisons : 0;
  }

  // 4. FORM SIMILARITY (10% weight)
  calculateFormSimilarity(suspiciousForms) {
    if (!this.baseline || !suspiciousForms || suspiciousForms.length === 0) return 0;

    const baselineForms = this.baseline.data.forms;
    if (baselineForms.length === 0) return 0;

    let maxSimilarity = 0;

    baselineForms.forEach(baseForm => {
      suspiciousForms.forEach(suspForm => {
        const similarity = this.compareFormFields(baseForm.fields, suspForm.fields);
        maxSimilarity = Math.max(maxSimilarity, similarity);
      });
    });

    return maxSimilarity * 100;
  }

  compareFormFields(fields1, fields2) {
    if (fields1.length === 0 && fields2.length === 0) return 0;

    let matches = 0;
    const total = Math.max(fields1.length, fields2.length);

    fields1.forEach(f1 => {
      const found = fields2.find(f2 =>
        f2.type === f1.type &&
        (f2.name === f1.name || f2.id === f1.id || f2.placeholder === f1.placeholder)
      );
      if (found) matches++;
    });

    return total > 0 ? matches / total : 0;
  }

  // 5. VISUAL SIMILARITY (30% weight) - Perceptual Hash
  async calculateVisualSimilarity(baselineScreenshot, suspiciousScreenshot) {
    try {
      const img1 = await Jimp.read(baselineScreenshot);
      const img2 = await Jimp.read(suspiciousScreenshot);

      const width = 256;
      const height = 256;
      img1.resize(width, height);
      img2.resize(height, height);

      const buf1 = await img1.getBufferAsync(Jimp.MIME_PNG);
      const buf2 = await img2.getBufferAsync(Jimp.MIME_PNG);

      const png1 = PNG.sync.read(buf1);
      const png2 = PNG.sync.read(buf2);

      const diff = new PNG({ width, height });
      const numDiffPixels = pixelmatch(
        png1.data, png2.data, diff.data,
        width, height,
        { threshold: 0.1 }
      );

      const totalPixels = width * height;
      const similarity = (1 - numDiffPixels / totalPixels) * 100;

      return Math.max(0, similarity);

    } catch (error) {
      console.error('Visual comparison failed:', error.message);
      return 0;
    }
  }

  // COMPOSITE SCORING with weighted average
  calculateCompositeScore(scores) {
    const weights = {
      visual: 0.30,
      text: 0.25,
      dom: 0.20,
      keywords: 0.15,
      forms: 0.10
    };

    const composite = (
      scores.visual * weights.visual +
      scores.text * weights.text +
      scores.dom * weights.dom +
      scores.keywords * weights.keywords +
      scores.forms * weights.forms
    );

    return Math.round(composite);
  }

  // FALSE POSITIVE FILTERING
  async filterFalsePositives(domain, data, scores) {
    const filters = [];

    if (CONFIG.whitelist.some(d => domain.includes(d))) {
      filters.push({ type: 'whitelist', reason: 'Domain is whitelisted', confidence: 100 });
      return { isFiltered: true, filters };
    }

    const text = data.text.toLowerCase();
    const contentTypes = [
      { type: 'news', keywords: ['article', 'published', 'author', 'news', 'reported'], threshold: 3 },
      { type: 'review', keywords: ['review', 'rating', 'customer', 'feedback', 'opinion'], threshold: 3 },
      { type: 'forum', keywords: ['forum', 'discussion', 'thread', 'posted by', 'reply'], threshold: 3 },
      { type: 'blog', keywords: ['blog', 'posted', 'comments', 'written by'], threshold: 2 }
    ];

    for (const ct of contentTypes) {
      const matches = ct.keywords.filter(kw => text.includes(kw)).length;
      if (matches >= ct.threshold) {
        filters.push({
          type: 'content_type',
          reason: `Appears to be a ${ct.type} site mentioning the brand`,
          confidence: (matches / ct.keywords.length) * 100
        });
      }
    }

    const contextualKeywords = [
      'about', 'review of', 'comparison', 'vs', 'versus',
      'what is', 'how to use', 'guide to', 'analysis of'
    ];
    const contextMatches = contextualKeywords.filter(kw => text.includes(kw)).length;
    if (contextMatches >= 2) {
      filters.push({
        type: 'contextual',
        reason: 'Content appears to be informational/editorial',
        confidence: (contextMatches / contextualKeywords.length) * 100
      });
    }

    if (scores.forms < 20 && scores.text > 60 && scores.visual < 50) {
      filters.push({
        type: 'pattern',
        reason: 'Text mentions brand but lacks login forms - likely news/review',
        confidence: 75
      });
    }

    const isFiltered = filters.length > 0 && filters.some(f => f.confidence > 70);
    return { isFiltered, filters };
  }

  determineThreatLevel(compositeScore, filters) {
    if (filters.isFiltered) {
      return 'legitimate';
    }

    if (compositeScore >= CONFIG.thresholds.critical) {
      return 'critical';
    } else if (compositeScore >= CONFIG.thresholds.warning) {
      return 'warning';
    } else if (compositeScore >= CONFIG.thresholds.suspicious) {
      return 'suspicious';
    } else {
      return 'safe';
    }
  }
}

// ============================================================================
// ENHANCED DOMAIN CHECKING (ORIGINAL LOGIC - UNCHANGED)
// ============================================================================

async function checkDomainWithRealDetection(domain) {
  console.log(`\n🔍 Analyzing domain: ${domain}`);

  let browser;
  try {
    const baseline = await baselineManager.ensureFreshBaseline();

    if (!baseline) {
      throw new Error('No baseline available');
    }

    browser = await puppeteer.launch({
      headless: 'new',
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
    });

    const page = await browser.newPage();
    await page.setViewport({ width: 1920, height: 1080 });

    let isActive = false;
    let suspiciousData = null;
    let screenshotPath = null;

    try {
      await page.goto(`http://${domain}`, {
        waitUntil: 'networkidle2',
        timeout: 15000
      });

      await page.waitForTimeout(2000);
      isActive = true;

      suspiciousData = await page.evaluate(() => {
        const removeTimestamps = (text) => {
          return text
            .replace(/\d{4}-\d{2}-\d{2}/g, 'DATE')
            .replace(/\d{2}:\d{2}:\d{2}/g, 'TIME')
            .replace(/\d{13,}/g, 'TIMESTAMP')
            .replace(/[a-f0-9]{32,}/gi, 'HASH');
        };

        const bodyText = document.body.innerText || '';
        const normalizedText = removeTimestamps(bodyText);

        const keywords = [];
        const keywordElements = document.querySelectorAll('h1, h2, h3, .logo, .brand, #logo');
        keywordElements.forEach(el => {
          if (el.textContent.trim()) {
            keywords.push(el.textContent.trim().toLowerCase());
          }
        });

        const forms = [];
        document.querySelectorAll('form').forEach(form => {
          const fields = [];
          form.querySelectorAll('input, select, textarea').forEach(input => {
            fields.push({
              type: input.type || input.tagName.toLowerCase(),
              name: input.name,
              id: input.id,
              placeholder: input.placeholder
            });
          });
          forms.push({ fields, action: form.action });
        });

        const getDOMStructure = (node, depth = 0) => {
          if (depth > 5) return null;
          const structure = {
            tag: node.tagName,
            classes: Array.from(node.classList || []),
            id: node.id
          };
          if (node.children.length > 0 && depth < 5) {
            structure.children = Array.from(node.children)
              .slice(0, 10)
              .map(child => getDOMStructure(child, depth + 1))
              .filter(Boolean);
          }
          return structure;
        };

        return {
          text: normalizedText,
          keywords,
          forms,
          domStructure: getDOMStructure(document.body)
        };
      });

      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
      const safeDomain = domain.replace(/[^a-zA-Z0-9.-]/g, '_');
      const filename = `${safeDomain}_${timestamp}.png`;
      screenshotPath = path.join(CONFIG.screenshotsFolder, filename);

      await page.screenshot({
        path: screenshotPath,
        fullPage: false
      });

      console.log(`✓ Data extracted from ${domain}`);

    } catch (error) {
      console.log(`✓ Domain is inactive or unreachable`);
      isActive = false;
    }

    if (!isActive) {
      return {
        isActive: false,
        similarity: 0,
        scores: {},
        threatLevel: 'safe',
        screenshotPath: null
      };
    }

    const detector = new PhishingDetector(baseline);

    console.log(`  → Calculating text similarity...`);
    const textScore = detector.calculateTextSimilarity(suspiciousData.text);

    console.log(`  → Checking brand keywords...`);
    const keywordScore = detector.calculateKeywordSimilarity(suspiciousData);

    console.log(`  → Analyzing DOM structure...`);
    const domScore = detector.calculateDOMSimilarity(suspiciousData.domStructure);

    console.log(`  → Comparing form fields...`);
    const formScore = detector.calculateFormSimilarity(suspiciousData.forms);

    console.log(`  → Running visual comparison...`);
    const visualScore = await detector.calculateVisualSimilarity(
      baseline.screenshotPath,
      screenshotPath
    );

    const scores = {
      text: Math.round(textScore),
      keywords: Math.round(keywordScore),
      dom: Math.round(domScore),
      forms: Math.round(formScore),
      visual: Math.round(visualScore)
    };

    const compositeScore = detector.calculateCompositeScore(scores);

    console.log(`  → Filtering false positives...`);
    const filters = await detector.filterFalsePositives(domain, suspiciousData, scores);

    const threatLevel = detector.determineThreatLevel(compositeScore, filters);

    const result = {
      isActive: true,
      similarity: compositeScore,
      scores,
      threatLevel,
      screenshotPath: path.basename(screenshotPath),
      filters: filters.filters,
      isFiltered: filters.isFiltered
    };

    console.log(`✓ Analysis complete: ${compositeScore}% similarity (${threatLevel})`);

    return result;

  } catch (error) {
    console.error(`✗ Domain check failed:`, error.message);
    return {
      isActive: false,
      similarity: 0,
      error: error.message
    };
  } finally {
    if (browser) await browser.close();
  }
}

// ============================================================================
// CSV LOGGING (ORIGINAL - UNCHANGED)
// ============================================================================

function getCurrentLogPath() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hour = String(now.getHours()).padStart(2, '0');

  const filename = `log_${year}-${month}-${day}_${hour}00.csv`;
  return path.join(CONFIG.logsFolder, filename);
}

async function ensureLogFile() {
  const logPath = getCurrentLogPath();

  try {
    await fs.access(logPath);
  } catch {
    const csvWriter = createObjectCsvWriter({
      path: logPath,
      header: [
        { id: 'timestamp', title: 'Timestamp' },
        { id: 'domain', title: 'Domain' },
        { id: 'alertType', title: 'Alert Type' },
        { id: 'status', title: 'Status' },
        { id: 'isActive', title: 'Is Active' },
        { id: 'compositeScore', title: 'Composite Score (%)' },
        { id: 'textScore', title: 'Text Score (%)' },
        { id: 'visualScore', title: 'Visual Score (%)' },
        { id: 'domScore', title: 'DOM Score (%)' },
        { id: 'keywordScore', title: 'Keyword Score (%)' },
        { id: 'formScore', title: 'Form Score (%)' },
        { id: 'threatLevel', title: 'Threat Level' },
        { id: 'isFiltered', title: 'Filtered as False Positive' },
        { id: 'screenshotPath', title: 'Screenshot Path' },
        { id: 'metadata', title: 'Metadata' }
      ]
    });

    await csvWriter.writeRecords([]);
    console.log(`Created new log file: ${logPath}`);
  }
}

async function logToCSV(data) {
  await ensureLogFile();
  const logPath = getCurrentLogPath();

  const csvWriter = createObjectCsvWriter({
    path: logPath,
    header: [
      { id: 'timestamp', title: 'Timestamp' },
      { id: 'domain', title: 'Domain' },
      { id: 'alertType', title: 'Alert Type' },
      { id: 'status', title: 'Status' },
      { id: 'isActive', title: 'Is Active' },
      { id: 'compositeScore', title: 'Composite Score (%)' },
      { id: 'textScore', title: 'Text Score (%)' },
      { id: 'visualScore', title: 'Visual Score (%)' },
      { id: 'domScore', title: 'DOM Score (%)' },
      { id: 'keywordScore', title: 'Keyword Score (%)' },
      { id: 'formScore', title: 'Form Score (%)' },
      { id: 'threatLevel', title: 'Threat Level' },
      { id: 'isFiltered', title: 'Filtered as False Positive' },
      { id: 'screenshotPath', title: 'Screenshot Path' },
      { id: 'metadata', title: 'Metadata' }
    ],
    append: true
  });

  await csvWriter.writeRecords([{
    timestamp: data.timestamp || new Date().toISOString(),
    domain: data.domain || '',
    alertType: data.alertType || 'Check',
    status: data.status || 'Checked',
    isActive: data.isActive ? 'Yes' : 'No',
    compositeScore: data.compositeScore || 0,
    textScore: data.scores?.text || 0,
    visualScore: data.scores?.visual || 0,
    domScore: data.scores?.dom || 0,
    keywordScore: data.scores?.keywords || 0,
    formScore: data.scores?.forms || 0,
    threatLevel: data.threatLevel || 'unknown',
    isFiltered: data.isFiltered ? 'Yes' : 'No',
    screenshotPath: data.screenshotPath || '',
    metadata: data.metadata || ''
  }]);
}

// ============================================================================
// TWILIO WHATSAPP ALERT SYSTEM
// ============================================================================

async function sendWhatsAppAlert(alertData) {
  if (!twilioClient || !TWILIO_CONFIG.toNumber) {
    console.log('⚠ WhatsApp alerts not configured, skipping');
    return { success: false, reason: 'not_configured' };
  }

  const message = [
    '🚨 *PHISHING THREAT DETECTED*',
    '',
    `🌐 *Domain:* ${alertData.domain}`,
    `⚠️ *Severity:* ${alertData.severity?.toUpperCase()}`,
    `📊 *Similarity:* ${alertData.similarity}%`,
    '',
    '📈 *Detection Scores:*',
    `  Visual: ${alertData.scores?.visual || 0}%`,
    `  Text: ${alertData.scores?.text || 0}%`,
    `  DOM: ${alertData.scores?.dom || 0}%`,
    `  Keywords: ${alertData.scores?.keywords || 0}%`,
    `  Forms: ${alertData.scores?.forms || 0}%`,
    '',
    `🕐 *Detected:* ${new Date(alertData.detected_at).toLocaleString()}`,
    '',
    '⚡ Immediate action recommended.'
  ].join('\n');

  for (let attempt = 1; attempt <= TWILIO_CONFIG.maxRetries; attempt++) {
    try {
      const result = await twilioClient.messages.create({
        body: message,
        from: TWILIO_CONFIG.fromNumber,
        to: TWILIO_CONFIG.toNumber
      });

      // Log success
      db.prepare(`
        INSERT INTO whatsapp_log (alert_id, message_sid, to_number, status, attempt_number)
        VALUES (?, ?, ?, 'sent', ?)
      `).run(alertData.id, result.sid, TWILIO_CONFIG.toNumber, attempt);

      // Update alert
      db.prepare(`
        UPDATE alerts SET whatsapp_status = 'sent', whatsapp_sent_at = datetime('now'), whatsapp_attempts = ?
        WHERE id = ?
      `).run(attempt, alertData.id);

      console.log(`✓ WhatsApp alert sent (attempt ${attempt}): ${result.sid}`);
      return { success: true, sid: result.sid };

    } catch (error) {
      console.error(`✗ WhatsApp attempt ${attempt} failed:`, error.message);

      // Log failure
      db.prepare(`
        INSERT INTO whatsapp_log (alert_id, to_number, status, error_message, attempt_number)
        VALUES (?, ?, 'failed', ?, ?)
      `).run(alertData.id, TWILIO_CONFIG.toNumber, error.message, attempt);

      if (attempt === TWILIO_CONFIG.maxRetries) {
        db.prepare(`
          UPDATE alerts SET whatsapp_status = 'failed', whatsapp_attempts = ?, whatsapp_last_error = ?
          WHERE id = ?
        `).run(attempt, error.message, alertData.id);

        return { success: false, error: error.message };
      }

      // Wait before retry (exponential backoff)
      await new Promise(r => setTimeout(r, attempt * 2000));
    }
  }
}

// ============================================================================
// API ROUTES (PROTECTED)
// ============================================================================

app.get('/api/config', (req, res) => {
  res.json({
    ...CONFIG,
    baselineAge: baselineManager.lastUpdate ?
      Math.round((Date.now() - baselineManager.lastUpdate.getTime()) / 60000) + ' minutes' :
      'unknown'
  });
});

// --- DOMAIN MANAGEMENT (PERSISTENT) ---

app.get('/api/domains', (req, res) => {
  const domains = db.prepare('SELECT * FROM domains ORDER BY added_at DESC').all();
  const mapped = domains.map(d => ({
    domain: d.domain,
    status: d.status,
    isActive: !!d.is_active,
    similarity: d.similarity,
    threatLevel: d.threat_level,
    scores: JSON.parse(d.scores_json || '{}'),
    filters: JSON.parse(d.filters_json || '[]'),
    isFiltered: !!d.is_filtered,
    screenshotPath: d.screenshot_path,
    lastChecked: d.last_checked,
    addedAt: d.added_at,
    monitoringEnabled: !!d.monitoring_enabled,
    scanCount: d.scan_count
  }));
  res.json(mapped);
});

app.post('/api/domains', (req, res) => {
  const { domain } = req.body;
  if (!domain) return res.status(400).json({ error: 'Domain is required' });

  try {
    db.prepare(`
      INSERT OR IGNORE INTO domains (domain, added_at)
      VALUES (?, datetime('now'))
    `).run(domain.trim());

    const d = db.prepare('SELECT * FROM domains WHERE domain = ?').get(domain.trim());
    res.json({
      domain: d.domain,
      status: d.status,
      isActive: !!d.is_active,
      similarity: d.similarity,
      threatLevel: d.threat_level,
      scores: JSON.parse(d.scores_json || '{}'),
      filters: JSON.parse(d.filters_json || '[]'),
      isFiltered: !!d.is_filtered,
      screenshotPath: d.screenshot_path,
      lastChecked: d.last_checked,
      addedAt: d.added_at,
      monitoringEnabled: !!d.monitoring_enabled
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/domains/:domain', (req, res) => {
  const { domain } = req.params;
  db.prepare('DELETE FROM domains WHERE domain = ?').run(domain);
  logToCSV({
    domain,
    alertType: 'Info',
    status: 'Removed from Watchlist',
    isActive: false,
    compositeScore: 0
  });
  res.json({ success: true });
});

app.patch('/api/domains/:domain/monitoring', (req, res) => {
  const { domain } = req.params;
  const { enabled } = req.body;
  db.prepare('UPDATE domains SET monitoring_enabled = ? WHERE domain = ?').run(enabled ? 1 : 0, domain);
  res.json({ success: true });
});

// --- DOMAIN CHECK (uses original detection engine) ---

app.post('/api/check-domain', async (req, res) => {
  const { domain } = req.body;

  if (!domain) {
    return res.status(400).json({ error: 'Domain is required' });
  }

  try {
    const result = await checkDomainWithRealDetection(domain);

    // Update domain record in DB
    db.prepare(`
      UPDATE domains SET
        status = 'checked',
        is_active = ?,
        similarity = ?,
        threat_level = ?,
        scores_json = ?,
        filters_json = ?,
        is_filtered = ?,
        screenshot_path = ?,
        last_checked = datetime('now'),
        scan_count = scan_count + 1,
        updated_at = datetime('now')
      WHERE domain = ?
    `).run(
      result.isActive ? 1 : 0,
      result.similarity || 0,
      result.threatLevel || 'unknown',
      JSON.stringify(result.scores || {}),
      JSON.stringify(result.filters || []),
      result.isFiltered ? 1 : 0,
      result.screenshotPath || null,
      domain
    );

    // Log to CSV
    await logToCSV({
      domain,
      alertType: result.threatLevel === 'critical' ? 'Critical' :
                 result.threatLevel === 'warning' ? 'Warning' : 'Check',
      status: 'Checked',
      isActive: result.isActive,
      compositeScore: result.similarity,
      scores: result.scores,
      threatLevel: result.threatLevel,
      isFiltered: result.isFiltered,
      screenshotPath: result.screenshotPath || ''
    });

    res.json(result);
  } catch (error) {
    console.error('Domain check error:', error);
    res.status(500).json({ error: 'Domain check failed' });
  }
});

// --- ALERTS (PERSISTENT) ---

app.post('/api/log-alert', async (req, res) => {
  const alertData = req.body;
  try {
    const info = db.prepare(`
      INSERT INTO alerts (domain, similarity, severity, threat_level, scores_json, screenshot_path, detected_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      alertData.domain,
      alertData.similarity || 0,
      alertData.severity || 'warning',
      alertData.threatLevel || 'unknown',
      JSON.stringify(alertData.scores || {}),
      alertData.screenshotPath || null,
      alertData.detectedAt || new Date().toISOString()
    );

    // Log to CSV
    await logToCSV({
      domain: alertData.domain,
      alertType: alertData.severity === 'critical' ? 'Critical' : 'Warning',
      status: 'Alert Triggered',
      isActive: true,
      compositeScore: alertData.similarity,
      scores: alertData.scores || {},
      threatLevel: alertData.threatLevel,
      screenshotPath: alertData.screenshotPath || '',
      metadata: JSON.stringify({ detectedAt: alertData.detectedAt })
    });

    // Send WhatsApp alert
    const alertId = info.lastInsertRowid;
    if (TWILIO_ENABLED && (alertData.severity === 'critical' || alertData.severity === 'warning')) {
      sendWhatsAppAlert({
        id: alertId,
        domain: alertData.domain,
        severity: alertData.severity,
        similarity: alertData.similarity,
        scores: alertData.scores,
        detected_at: alertData.detectedAt
      }).catch(err => console.error('WhatsApp alert error:', err.message));
    }

    res.json({ success: true, alertId });
  } catch (error) {
    res.status(500).json({ error: 'Failed to log alert' });
  }
});

app.get('/api/alerts', (req, res) => {
  const { status, limit } = req.query;
  let query = 'SELECT * FROM alerts';
  const params = [];

  if (status) {
    query += ' WHERE status = ?';
    params.push(status);
  }

  query += ' ORDER BY created_at DESC';

  if (limit) {
    query += ' LIMIT ?';
    params.push(parseInt(limit));
  }

  const alerts = db.prepare(query).all(...params);
  const mapped = alerts.map(a => ({
    id: a.id,
    domain: a.domain,
    similarity: a.similarity,
    severity: a.severity,
    threatLevel: a.threat_level,
    scores: JSON.parse(a.scores_json || '{}'),
    screenshotPath: a.screenshot_path,
    detectedAt: a.detected_at,
    status: a.status,
    whatsappStatus: a.whatsapp_status,
    whatsappAttempts: a.whatsapp_attempts,
    whatsappLastError: a.whatsapp_last_error,
    whatsappSentAt: a.whatsapp_sent_at,
    dismissed: !!a.dismissed,
    dismissedAt: a.dismissed_at
  }));
  res.json(mapped);
});

app.patch('/api/alerts/:id/dismiss', (req, res) => {
  const { id } = req.params;
  db.prepare(`UPDATE alerts SET dismissed = 1, dismissed_at = datetime('now'), status = 'dismissed' WHERE id = ?`).run(id);
  res.json({ success: true });
});

app.get('/api/alerts/queue', (req, res) => {
  const pending = db.prepare(`SELECT * FROM alerts WHERE status = 'pending' AND dismissed = 0 ORDER BY created_at DESC`).all();
  const processed = db.prepare(`SELECT * FROM alerts WHERE status != 'pending' ORDER BY created_at DESC LIMIT 50`).all();

  res.json({
    pending: pending.map(a => ({ ...a, scores: JSON.parse(a.scores_json || '{}') })),
    processed: processed.map(a => ({ ...a, scores: JSON.parse(a.scores_json || '{}') })),
    counts: {
      pending: pending.length,
      total: db.prepare('SELECT COUNT(*) as count FROM alerts').get().count,
      whatsappSent: db.prepare(`SELECT COUNT(*) as count FROM alerts WHERE whatsapp_status = 'sent'`).get().count,
      whatsappFailed: db.prepare(`SELECT COUNT(*) as count FROM alerts WHERE whatsapp_status = 'failed'`).get().count
    }
  });
});

// --- WHATSAPP LOG ---

app.get('/api/whatsapp-log', (req, res) => {
  const logs = db.prepare('SELECT * FROM whatsapp_log ORDER BY created_at DESC LIMIT 100').all();
  res.json(logs);
});

// --- SCAN PROGRESS ---

app.get('/api/scan-progress', (req, res) => {
  const latest = db.prepare(`SELECT * FROM scan_progress ORDER BY started_at DESC LIMIT 1`).get();
  res.json(latest || { status: 'idle' });
});

app.post('/api/scan-progress', (req, res) => {
  const { scanId, totalDomains, scannedDomains, currentDomain, currentPhase, status } = req.body;

  if (status === 'started') {
    db.prepare(`
      INSERT OR REPLACE INTO scan_progress (scan_id, total_domains, scanned_domains, current_domain, current_phase, started_at, status)
      VALUES (?, ?, 0, '', 'initializing', datetime('now'), 'running')
    `).run(scanId, totalDomains);
  } else if (status === 'progress') {
    db.prepare(`
      UPDATE scan_progress SET scanned_domains = ?, current_domain = ?, current_phase = ?, status = 'running'
      WHERE scan_id = ?
    `).run(scannedDomains, currentDomain, currentPhase, scanId);
  } else if (status === 'completed') {
    db.prepare(`
      UPDATE scan_progress SET status = 'completed', completed_at = datetime('now'), scanned_domains = total_domains
      WHERE scan_id = ?
    `).run(scanId);
  }

  res.json({ success: true });
});

// --- BASELINE ---

app.post('/api/refresh-baseline', async (req, res) => {
  try {
    const baseline = await baselineManager.refreshBaseline();
    res.json({
      success: true,
      timestamp: baseline.timestamp
    });
  } catch (error) {
    res.status(500).json({ error: 'Baseline refresh failed' });
  }
});

// --- HISTORICAL DATA ---

app.get('/api/historical', async (req, res) => {
  try {
    const domainDirs = await fs.readdir(CONFIG.domainsFolder);
    const allHistory = [];

    for (const domainDir of domainDirs) {
      const historyFile = path.join(CONFIG.domainsFolder, domainDir, 'history.json');

      try {
        const content = await fs.readFile(historyFile, 'utf8');
        const history = JSON.parse(content);

        history.forEach(record => {
          allHistory.push({
            domain: domainDir.replace(/_/g, '.'),
            ...record
          });
        });
      } catch {}
    }

    allHistory.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    res.json(allHistory);
  } catch (error) {
    res.json([]);
  }
});

// --- SCREENSHOTS ---

app.get('/api/screenshot/:filename', async (req, res) => {
  const { filename } = req.params;
  const filePath = path.join(CONFIG.screenshotsFolder, filename);

  try {
    await fs.access(filePath);
    res.sendFile(filePath);
  } catch {
    res.status(404).json({ error: 'Screenshot not found' });
  }
});

// --- BACKWARD COMPAT: DELETE watchlist endpoint ---

app.delete('/api/watchlist/:domain', (req, res) => {
  const { domain } = req.params;
  db.prepare('DELETE FROM domains WHERE domain = ?').run(domain);
  logToCSV({
    domain,
    alertType: 'Info',
    status: 'Removed from Watchlist',
    isActive: false,
    compositeScore: 0
  });
  res.json({ success: true });
});

// ============================================================================
// SPA FALLBACK - serve React for all non-API routes
// ============================================================================

app.get('*', (req, res) => {
  const indexPath = path.join(buildPath, 'index.html');
  if (fsSync.existsSync(indexPath)) {
    res.sendFile(indexPath);
  } else {
    res.status(404).json({ error: 'Frontend build not found. Run: npm run build' });
  }
});

// ============================================================================
// START SERVER
// ============================================================================

async function startServer() {
  await initializeDirectories();
  initDatabase();
  ensureDefaultAdmin();

  console.log('\n🔧 Initializing Phishing Detection Engine...');
  await baselineManager.loadBaseline();

  app.listen(PORT, '0.0.0.0', () => {
    console.log('\n');
    console.log('═══════════════════════════════════════════════════════════════');
    console.log('   ✨ Enhanced Phishing Defense Backend (Production)');
    console.log('═══════════════════════════════════════════════════════════════');
    console.log(`   Status: ONLINE`);
    console.log(`   Port: ${PORT}`);
    console.log(`   URL: http://0.0.0.0:${PORT}`);
    console.log('');
    console.log('   🔐 Authentication: JWT (24h expiry)');
    console.log(`   📱 WhatsApp Alerts: ${TWILIO_ENABLED ? 'ENABLED' : 'DISABLED'}`);
    console.log(`   💾 Database: SQLite (persistent)`);
    console.log('');
    console.log('   🎯 Detection Methods:');
    console.log('   ✓ Text Similarity (TF-IDF) - 25%');
    console.log('   ✓ Visual Comparison (Perceptual Hash) - 30%');
    console.log('   ✓ DOM Structure Analysis - 20%');
    console.log('   ✓ Brand Keyword Matching - 15%');
    console.log('   ✓ Form Field Comparison - 10%');
    console.log('');
    console.log('   🛡️ False Positive Filtering:');
    console.log('   ✓ Whitelist checking');
    console.log('   ✓ Content type detection');
    console.log('   ✓ Contextual analysis');
    console.log('');
    console.log('   📊 Thresholds:');
    console.log(`   • Critical: ${CONFIG.thresholds.critical}%`);
    console.log(`   • Warning: ${CONFIG.thresholds.warning}%`);
    console.log(`   • Suspicious: ${CONFIG.thresholds.suspicious}%`);
    console.log('');
    console.log(`   ⟳ Baseline: ${baselineManager.lastUpdate ? baselineManager.lastUpdate.toLocaleString() : 'Not loaded'}`);
    console.log('═══════════════════════════════════════════════════════════════');
    console.log('');
  });
}

startServer().catch(console.error);
