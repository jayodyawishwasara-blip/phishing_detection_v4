# Phishing Defense Dashboard — Production Deployment

## Quick Start (Single Command)

```bash
# Upload all files to your VPS, then:
chmod +x deploy.sh
sudo ./deploy.sh
```

That's it. The script handles everything automatically.

---

## What Gets Deployed

| Component | Technology | Purpose |
|-----------|-----------|---------|
| Frontend | React (production build) | Dashboard UI (unchanged) |
| Backend | Node.js + Express | Detection engine + API |
| Database | SQLite | Persistent domains, alerts, configs |
| Auth | JWT + bcrypt | Secure admin login |
| Proxy | Caddy | HTTPS, reverse proxy, static files |
| Alerts | Twilio (optional) | WhatsApp notifications |
| Service | systemd | Auto-start on reboot |
| Firewall | UFW | Port 80/443 only |

---

## After Deployment

### Access
- **URL:** `http://<YOUR_VPS_IP>`
- **Login:** `admin` / `PhishGuard@2026`

### Configure
```bash
sudo nano /opt/phishing-defense/backend/.env
sudo systemctl restart phishing-defense
```

### Enable HTTPS (with a domain)
1. Point your domain DNS to your VPS IP
2. Edit `/etc/caddy/Caddyfile`
3. Replace `:80 {` with `yourdomain.com {`
4. `sudo systemctl restart caddy`
5. Caddy auto-provisions Let's Encrypt certificate

### Enable WhatsApp Alerts
Add to `.env`:
```
TWILIO_ACCOUNT_SID=your_sid
TWILIO_AUTH_TOKEN=your_token
TWILIO_WHATSAPP_FROM=whatsapp:+14155238886
TWILIO_WHATSAPP_TO=whatsapp:+94XXXXXXXXX
```

---

## Persistence

All data survives reboots:

| Data | Storage | Location |
|------|---------|----------|
| Monitored domains | SQLite | `/opt/phishing-defense/data/phishing-defense.db` |
| Alerts + history | SQLite | Same DB |
| WhatsApp delivery log | SQLite | Same DB |
| Baseline snapshots | File | `/opt/phishing-defense/data/baseline/` |
| Screenshots | File | `/opt/phishing-defense/data/screenshots/` |
| CSV logs | File | `/opt/phishing-defense/data/logs/` |

---

## API Endpoints

### Public
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check |
| POST | `/api/auth/login` | Login (returns JWT) |
| POST | `/api/auth/verify` | Verify token |

### Protected (requires `Authorization: Bearer <token>`)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/config` | Server configuration |
| GET | `/api/domains` | List all monitored domains |
| POST | `/api/domains` | Add domain |
| DELETE | `/api/domains/:domain` | Remove domain |
| PATCH | `/api/domains/:domain/monitoring` | Toggle monitoring |
| POST | `/api/check-domain` | Scan a domain |
| GET | `/api/alerts` | List alerts |
| GET | `/api/alerts/queue` | Alert queue + stats |
| PATCH | `/api/alerts/:id/dismiss` | Dismiss alert |
| POST | `/api/log-alert` | Create alert |
| GET | `/api/scan-progress` | Current scan progress |
| POST | `/api/scan-progress` | Update scan progress |
| GET | `/api/whatsapp-log` | WhatsApp delivery log |
| GET | `/api/historical` | Historical scan data |
| POST | `/api/refresh-baseline` | Force baseline refresh |
| GET | `/api/screenshot/:file` | View screenshot |
| POST | `/api/auth/change-password` | Change password |

---

## Service Management

```bash
# Status
sudo systemctl status phishing-defense

# Logs (live)
sudo journalctl -u phishing-defense -f

# Restart
sudo systemctl restart phishing-defense

# Stop
sudo systemctl stop phishing-defense

# Caddy logs
sudo journalctl -u caddy -f
```

---

## File Structure on VPS

```
/opt/phishing-defense/
├── frontend/
│   └── build/              → React production build (static)
├── backend/
│   ├── server-production.js → Express server
│   ├── package.json        → Dependencies
│   ├── node_modules/       → Installed packages
│   └── .env                → Configuration (SECRET)
├── data/
│   ├── phishing-defense.db → SQLite database
│   ├── baseline/           → Legitimate site snapshots
│   ├── screenshots/        → Evidence captures
│   ├── domains/            → Per-domain history (JSON)
│   └── logs/               → Hourly CSV logs
/etc/caddy/Caddyfile         → Reverse proxy config
/etc/systemd/system/phishing-defense.service → Service unit
```

---

## Unchanged from Original

- **UI/UX**: 100% preserved — same dark theme, tabs, cards, tables
- **Detection Engine**: All 5 methods (Visual, Text, DOM, Keywords, Forms)
- **Scoring**: Same weighted composite algorithm
- **Thresholds**: Same critical/warning/suspicious levels
- **False Positive Filtering**: Same whitelist + content type detection
- **CSV Logging**: Same hourly log format

## What Was Added

- SQLite persistence for domains and alerts
- JWT authentication gate (login screen)
- Twilio WhatsApp alert integration
- Caddy reverse proxy configuration
- systemd service for auto-restart
- UFW firewall rules
- Logout button in status bar
